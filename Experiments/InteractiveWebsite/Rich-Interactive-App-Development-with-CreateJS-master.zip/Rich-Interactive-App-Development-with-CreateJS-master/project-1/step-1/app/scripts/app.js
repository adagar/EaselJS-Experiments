(function() {
  console.log("Setting – Testing GulpJS setup");

}).call(this);

(function() {
  console.log("App – Testing GulpJS setup.");

}).call(this);
