# Practical CreateJS

Example code for my book—[Practical CreateJS][book link]



[book link]: http://mak.la/createjs
